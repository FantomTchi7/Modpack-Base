This pack is an Add-On for Bare Bones, most of the textures(not PBR) were made by Witze, the developer of Bare Bones
So if you see missing textures you might wanna use Bare Bones below this pack 
https://www.curseforge.com/minecraft/texture-packs/bare-bones-texture-pack